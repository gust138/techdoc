var class_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data_1_1_tarkov_dev_graph_q_l_api =
[
    [ "Configure", "class_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data_1_1_tarkov_dev_graph_q_l_api.html#a2c864047ef25c3b51effd520f126e516", null ],
    [ "GetTarkovDataAsync", "class_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data_1_1_tarkov_dev_graph_q_l_api.html#a59be9595a786d8fc8fe69c060f046224", null ]
];