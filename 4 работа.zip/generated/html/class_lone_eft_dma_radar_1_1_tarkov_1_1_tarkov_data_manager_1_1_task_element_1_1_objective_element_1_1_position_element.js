var class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_task_element_1_1_objective_element_1_1_position_element =
[
    [ "set", "class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_task_element_1_1_objective_element_1_1_position_element.html#a8be4c97aa335276434e8b67682ae91ea", null ],
    [ "X", "class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_task_element_1_1_objective_element_1_1_position_element.html#a8964cc335d57c2611ff44cf7b770ffb9", null ],
    [ "Y", "class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_task_element_1_1_objective_element_1_1_position_element.html#a1f4a63e6f0ad9963695a2662f541cd1e", null ],
    [ "Z", "class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_task_element_1_1_objective_element_1_1_position_element.html#abcc48560a8e18b3f6f07db9ee1dedd1c", null ]
];