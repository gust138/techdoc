var class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_extract_element =
[
    [ "Faction", "class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_extract_element.html#ad68693ab42fadc6cac4ebe05a00f19de", null ],
    [ "IsPmc", "class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_extract_element.html#aa1edc6547b851676a3fe659123b54817", null ],
    [ "IsShared", "class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_extract_element.html#a68e6c931d903b7f7e71a2b35c69d0fef", null ],
    [ "Name", "class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_extract_element.html#ac904c45ce00f1bf7d7d8a97d2c925cb0", null ],
    [ "Position", "class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_extract_element.html#ac1fdabd21a0ecffc632616742603f9e7", null ],
    [ "set", "class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_extract_element.html#ae6fde14a02a44abcc62ea0874fc0cd06", null ]
];