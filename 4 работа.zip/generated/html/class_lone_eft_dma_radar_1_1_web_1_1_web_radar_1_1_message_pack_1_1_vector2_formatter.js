var class_lone_eft_dma_radar_1_1_web_1_1_web_radar_1_1_message_pack_1_1_vector2_formatter =
[
    [ "Deserialize", "class_lone_eft_dma_radar_1_1_web_1_1_web_radar_1_1_message_pack_1_1_vector2_formatter.html#a348e74b333a1b018187960dda128f5e9", null ],
    [ "Serialize", "class_lone_eft_dma_radar_1_1_web_1_1_web_radar_1_1_message_pack_1_1_vector2_formatter.html#ab8e1edf06ac54920ae7995373bcf9719", null ]
];