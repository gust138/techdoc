var struct_a_i_role =
[
    [ "init", "struct_a_i_role.html#a2b48880b08ce45626aaec058d7be58fa", null ],
    [ "Name", "struct_a_i_role.html#a655dbfee45eb47ec7661b9e9951b2430", null ],
    [ "Type", "struct_a_i_role.html#abb4e570b192c41c7cad52da85475fa3e", null ]
];