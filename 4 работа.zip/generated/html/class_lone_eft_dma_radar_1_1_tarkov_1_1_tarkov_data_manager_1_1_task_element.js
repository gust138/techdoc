var class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_task_element =
[
    [ "ObjectiveElement", "class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_task_element_1_1_objective_element.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_task_element_1_1_objective_element" ],
    [ "Id", "class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_task_element.html#aba42bc93c59d3c5da29af44cab927d2f", null ],
    [ "Name", "class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_task_element.html#ac03c4180343dc29ff8e7688cc0b36d61", null ],
    [ "Objectives", "class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_task_element.html#a0e7bd606922e6ec30c86a3a768c00621", null ],
    [ "set", "class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager_1_1_task_element.html#acf85a1863ad4a4c5fc776be3370761ff", null ]
];