var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "DMA", "dir_355dbffde3ab0067750f5635268d01c1.html", "dir_355dbffde3ab0067750f5635268d01c1" ],
    [ "Misc", "dir_4b4044e7774ae858aac25fb7cd85b90b.html", "dir_4b4044e7774ae858aac25fb7cd85b90b" ],
    [ "Tarkov", "dir_d4ec72cf164d1318fbc33c5c2046d557.html", "dir_d4ec72cf164d1318fbc33c5c2046d557" ],
    [ "UI", "dir_7ad25bca70c4d3d9103f75d82f41ef94.html", "dir_7ad25bca70c4d3d9103f75d82f41ef94" ],
    [ "Web", "dir_2f7b293845ef2dc4967d47cb94f137d6.html", "dir_2f7b293845ef2dc4967d47cb94f137d6" ],
    [ "App.xaml.cs", "_app_8xaml_8cs.html", "_app_8xaml_8cs" ],
    [ "EftDmaConfig.cs", "_eft_dma_config_8cs.html", "_eft_dma_config_8cs" ],
    [ "MainWindow.xaml.cs", "_main_window_8xaml_8cs.html", "_main_window_8xaml_8cs" ],
    [ "MainWindowViewModel.cs", "_main_window_view_model_8cs.html", "_main_window_view_model_8cs" ]
];