var dir_bcd710ebcca99df592b3801bea71c8b9 =
[
    [ "AntiAfk.cs", "_anti_afk_8cs.html", "_anti_afk_8cs" ],
    [ "ExtendedReach.cs", "_extended_reach_8cs.html", "_extended_reach_8cs" ],
    [ "InfiniteStamina.cs", "_infinite_stamina_8cs.html", "_infinite_stamina_8cs" ],
    [ "MemoryAim.cs", "_memory_aim_8cs.html", "_memory_aim_8cs" ],
    [ "MuleMode.cs", "_mule_mode_8cs.html", "_mule_mode_8cs" ],
    [ "NoRecoil.cs", "_no_recoil_8cs.html", "_no_recoil_8cs" ]
];