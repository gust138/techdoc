var class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_firearm_manager_1_1_magazine_manager =
[
    [ "_ammo", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_firearm_manager_1_1_magazine_manager.html#afe6d50171925c1c11a792682d258a9af", null ],
    [ "_fireType", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_firearm_manager_1_1_magazine_manager.html#a2e8f2cd115d947b7dbad07696c1e2ed3", null ],
    [ "_localPlayer", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_firearm_manager_1_1_magazine_manager.html#a83551406fbf918a52ffdc961598ac829", null ],
    [ "Count", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_firearm_manager_1_1_magazine_manager.html#a3c2730a25a2f476be251e2af59d3e108", null ],
    [ "IsValid", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_firearm_manager_1_1_magazine_manager.html#a23d86a27301ef2a1c9e4b14f01708225", null ],
    [ "MaxCount", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_firearm_manager_1_1_magazine_manager.html#a96ca3fcfb2325e0a5d674aad58b7dca1", null ],
    [ "set", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_firearm_manager_1_1_magazine_manager.html#aab3add5eb623ebb2dfc2e6f2877caf2c", null ]
];