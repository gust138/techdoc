var class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_ballistics_1_1_g1 =
[
    [ "CalculateDragCoefficient", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_ballistics_1_1_g1.html#a5c54358404d8b2b3f90e6c7b7eca20a1", null ],
    [ "_g1Coeffs", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_ballistics_1_1_g1.html#ae70bd6e87b06cc1d3763e249f391288f", null ]
];