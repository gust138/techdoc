var annotated_dup =
[
    [ "LoneEftDmaRadar", "namespace_lone_eft_dma_radar.html", [
      [ "Common", "namespace_lone_eft_dma_radar_1_1_common.html", [
        [ "DMA", "namespace_lone_eft_dma_radar_1_1_common_1_1_d_m_a.html", [
          [ "MemPointer", "struct_lone_eft_dma_radar_1_1_common_1_1_d_m_a_1_1_mem_pointer.html", "struct_lone_eft_dma_radar_1_1_common_1_1_d_m_a_1_1_mem_pointer" ]
        ] ],
        [ "Misc", "namespace_lone_eft_dma_radar_1_1_common_1_1_misc.html", [
          [ "Pools", "namespace_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_pools.html", [
            [ "ObjectPool", "class_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_pools_1_1_object_pool.html", "class_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_pools_1_1_object_pool" ],
            [ "SharedArray&lt; T &gt;", "class_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_pools_1_1_shared_array_3_01_t_01_4.html", "class_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_pools_1_1_shared_array_3_01_t_01_4" ]
          ] ],
          [ "DebugSwAverages", "struct_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_debug_sw_averages.html", "struct_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_debug_sw_averages" ],
          [ "RectFSer", "struct_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_rect_f_ser.html", "struct_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_rect_f_ser" ],
          [ "SizeChecker&lt; T &gt;", "class_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_size_checker_3_01_t_01_4.html", "class_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_size_checker_3_01_t_01_4" ],
          [ "UnicodeString", "class_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_unicode_string.html", "class_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_unicode_string" ],
          [ "Utils", "class_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_utils.html", "class_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_utils" ]
        ] ]
      ] ],
      [ "DMA", "namespace_lone_eft_dma_radar_1_1_d_m_a.html", [
        [ "InputManager", "class_lone_eft_dma_radar_1_1_d_m_a_1_1_input_manager.html", "class_lone_eft_dma_radar_1_1_d_m_a_1_1_input_manager" ],
        [ "Memory", "class_lone_eft_dma_radar_1_1_d_m_a_1_1_memory.html", "class_lone_eft_dma_radar_1_1_d_m_a_1_1_memory" ],
        [ "MemoryExtensions", "class_lone_eft_dma_radar_1_1_d_m_a_1_1_memory_extensions.html", null ]
      ] ],
      [ "Misc", "namespace_lone_eft_dma_radar_1_1_misc.html", [
        [ "JSON", "namespace_lone_eft_dma_radar_1_1_misc_1_1_j_s_o_n.html", [
          [ "CaseInsensitiveConcurrentDictionaryConverter&lt; TValue &gt;", "class_lone_eft_dma_radar_1_1_misc_1_1_j_s_o_n_1_1_case_insensitive_concurrent_dictionary_converter_3_01_t_value_01_4.html", "class_lone_eft_dma_radar_1_1_misc_1_1_j_s_o_n_1_1_case_insensitive_concurrent_dictionary_converter_3_01_t_value_01_4" ],
          [ "SKRectJsonConverter", "class_lone_eft_dma_radar_1_1_misc_1_1_j_s_o_n_1_1_s_k_rect_json_converter.html", "class_lone_eft_dma_radar_1_1_misc_1_1_j_s_o_n_1_1_s_k_rect_json_converter" ]
        ] ],
        [ "Services", "namespace_lone_eft_dma_radar_1_1_misc_1_1_services.html", [
          [ "LocalCache", "class_lone_eft_dma_radar_1_1_misc_1_1_services_1_1_local_cache.html", "class_lone_eft_dma_radar_1_1_misc_1_1_services_1_1_local_cache" ]
        ] ],
        [ "Workers", "namespace_lone_eft_dma_radar_1_1_misc_1_1_workers.html", [
          [ "WorkerThread", "class_lone_eft_dma_radar_1_1_misc_1_1_workers_1_1_worker_thread.html", "class_lone_eft_dma_radar_1_1_misc_1_1_workers_1_1_worker_thread" ],
          [ "WorkerThreadArgs", "class_lone_eft_dma_radar_1_1_misc_1_1_workers_1_1_worker_thread_args.html", "class_lone_eft_dma_radar_1_1_misc_1_1_workers_1_1_worker_thread_args" ]
        ] ],
        [ "MiscExtensions", "class_lone_eft_dma_radar_1_1_misc_1_1_misc_extensions.html", "class_lone_eft_dma_radar_1_1_misc_1_1_misc_extensions" ],
        [ "Native", "class_lone_eft_dma_radar_1_1_misc_1_1_native.html", "class_lone_eft_dma_radar_1_1_misc_1_1_native" ],
        [ "ResourceJanitor", "class_lone_eft_dma_radar_1_1_misc_1_1_resource_janitor.html", "class_lone_eft_dma_radar_1_1_misc_1_1_resource_janitor" ],
        [ "Utilities", "class_lone_eft_dma_radar_1_1_misc_1_1_utilities.html", "class_lone_eft_dma_radar_1_1_misc_1_1_utilities" ]
      ] ],
      [ "Tarkov", "namespace_lone_eft_dma_radar_1_1_tarkov.html", [
        [ "Features", "namespace_lone_eft_dma_radar_1_1_tarkov_1_1_features.html", [
          [ "MemWrites", "namespace_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes.html", [
            [ "AntiAfk", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_anti_afk.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_anti_afk" ],
            [ "ExtendedReach", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_extended_reach.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_extended_reach" ],
            [ "InfiniteStamina", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_infinite_stamina.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_infinite_stamina" ],
            [ "MemoryAim", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_memory_aim.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_memory_aim" ],
            [ "MemWritesManager", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_mem_writes_manager.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_mem_writes_manager" ],
            [ "MuleMode", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_mule_mode.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_mule_mode" ],
            [ "NoRecoil", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil" ],
            [ "T", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_t.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_t" ]
          ] ]
        ] ],
        [ "GameWorld", "namespace_lone_eft_dma_radar_1_1_tarkov_1_1_game_world.html", [
          [ "Camera", "namespace_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_camera.html", [
            [ "CameraManager", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_camera_1_1_camera_manager.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_camera_1_1_camera_manager" ],
            [ "ViewMatrix", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_camera_1_1_view_matrix.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_camera_1_1_view_matrix" ]
          ] ],
          [ "Exits", "namespace_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_exits.html", [
            [ "Exfil", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_exits_1_1_exfil.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_exits_1_1_exfil" ],
            [ "ExitManager", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_exits_1_1_exit_manager.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_exits_1_1_exit_manager" ],
            [ "TransitPoint", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_exits_1_1_transit_point.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_exits_1_1_transit_point" ]
          ] ],
          [ "Explosives", "namespace_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_explosives.html", [
            [ "ExplosivesManager", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_explosives_1_1_explosives_manager.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_explosives_1_1_explosives_manager" ],
            [ "Grenade", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_explosives_1_1_grenade.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_explosives_1_1_grenade" ],
            [ "Tripwire", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_explosives_1_1_tripwire.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_explosives_1_1_tripwire" ]
          ] ],
          [ "Loot", "namespace_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_loot.html", [
            [ "Helpers", "namespace_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_loot_1_1_helpers.html", [
              [ "LootExtensions", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_loot_1_1_helpers_1_1_loot_extensions.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_loot_1_1_helpers_1_1_loot_extensions" ]
            ] ],
            [ "LootAirdrop", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_loot_1_1_loot_airdrop.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_loot_1_1_loot_airdrop" ],
            [ "LootCorpse", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_loot_1_1_loot_corpse.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_loot_1_1_loot_corpse" ],
            [ "LootItem", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_loot_1_1_loot_item.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_loot_1_1_loot_item" ],
            [ "LootManager", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_loot_1_1_loot_manager.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_loot_1_1_loot_manager" ],
            [ "StaticLootContainer", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_loot_1_1_static_loot_container.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_loot_1_1_static_loot_container" ]
          ] ],
          [ "Player", "namespace_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player.html", [
            [ "Helpers", "namespace_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_helpers.html", [
              [ "PlayerEquipment", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_helpers_1_1_player_equipment.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_helpers_1_1_player_equipment" ]
            ] ],
            [ "AbstractPlayer", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_abstract_player.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_abstract_player" ],
            [ "BtrPlayer", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_btr_player.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_btr_player" ],
            [ "ClientPlayer", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_client_player.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_client_player" ],
            [ "LocalPlayer", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_local_player.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_local_player" ],
            [ "ObservedPlayer", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_observed_player.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_observed_player" ],
            [ "RaidInfoCache", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_raid_info_cache.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_raid_info_cache" ]
          ] ],
          [ "Quests", "namespace_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_quests.html", [
            [ "QuestEntry", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_quests_1_1_quest_entry.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_quests_1_1_quest_entry" ],
            [ "QuestLocation", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_quests_1_1_quest_location.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_quests_1_1_quest_location" ],
            [ "QuestManager", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_quests_1_1_quest_manager.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_quests_1_1_quest_manager" ]
          ] ],
          [ "GameWorldExtensions", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_game_world_extensions.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_game_world_extensions" ],
          [ "LocalGameWorld", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_local_game_world.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_local_game_world" ],
          [ "RegisteredPlayers", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_registered_players.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_registered_players" ]
        ] ],
        [ "Unity", "namespace_lone_eft_dma_radar_1_1_tarkov_1_1_unity.html", [
          [ "Collections", "namespace_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_collections.html", [
            [ "UnityArray&lt; T &gt;", "class_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_collections_1_1_unity_array_3_01_t_01_4.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_collections_1_1_unity_array_3_01_t_01_4" ],
            [ "UnityDictionary&lt; TKey, TValue &gt;", "class_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_collections_1_1_unity_dictionary_3_01_t_key_00_01_t_value_01_4.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_collections_1_1_unity_dictionary_3_01_t_key_00_01_t_value_01_4" ],
            [ "UnityHashSet&lt; T &gt;", "class_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_collections_1_1_unity_hash_set_3_01_t_01_4.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_collections_1_1_unity_hash_set_3_01_t_01_4" ],
            [ "UnityList&lt; T &gt;", "class_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_collections_1_1_unity_list_3_01_t_01_4.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_collections_1_1_unity_list_3_01_t_01_4" ]
          ] ],
          [ "Structures", "namespace_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures.html", [
            [ "AllCameras", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_all_cameras.html", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_all_cameras" ],
            [ "ComponentArray", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_component_array.html", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_component_array" ],
            [ "DynamicArray", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_dynamic_array.html", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_dynamic_array" ],
            [ "GameObject", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_game_object.html", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_game_object" ],
            [ "GameObjectManager", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_game_object_manager.html", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_game_object_manager" ],
            [ "LinkedListObject", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_linked_list_object.html", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_linked_list_object" ],
            [ "MonoBehaviour", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_mono_behaviour.html", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_mono_behaviour" ],
            [ "ObjectClass", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_object_class.html", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_object_class" ],
            [ "UnityComponent", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_unity_component.html", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_unity_component" ],
            [ "UnityTransform", "class_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_unity_transform.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_unity_transform" ]
          ] ],
          [ "UnitySDK", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_unity_s_d_k.html", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_unity_s_d_k" ]
        ] ],
        [ "MongoID", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_mongo_i_d.html", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_mongo_i_d" ],
        [ "TarkovDataManager", "class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager.html", "class_lone_eft_dma_radar_1_1_tarkov_1_1_tarkov_data_manager" ]
      ] ],
      [ "UI", "namespace_lone_eft_dma_radar_1_1_u_i.html", [
        [ "ColorPicker", "namespace_lone_eft_dma_radar_1_1_u_i_1_1_color_picker.html", [
          [ "ColorDictionaryConverter", "class_lone_eft_dma_radar_1_1_u_i_1_1_color_picker_1_1_color_dictionary_converter.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_color_picker_1_1_color_dictionary_converter" ],
          [ "ColorPickerViewModel", "class_lone_eft_dma_radar_1_1_u_i_1_1_color_picker_1_1_color_picker_view_model.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_color_picker_1_1_color_picker_view_model" ],
          [ "ColorPickerWindow", "class_lone_eft_dma_radar_1_1_u_i_1_1_color_picker_1_1_color_picker_window.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_color_picker_1_1_color_picker_window" ]
        ] ],
        [ "Converters", "namespace_lone_eft_dma_radar_1_1_u_i_1_1_converters.html", [
          [ "InverseBooleanConverter", "class_lone_eft_dma_radar_1_1_u_i_1_1_converters_1_1_inverse_boolean_converter.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_converters_1_1_inverse_boolean_converter" ]
        ] ],
        [ "Data", "namespace_lone_eft_dma_radar_1_1_u_i_1_1_data.html", [
          [ "ScreenEntry", "class_lone_eft_dma_radar_1_1_u_i_1_1_data_1_1_screen_entry.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_data_1_1_screen_entry" ],
          [ "StaticContainerEntry", "class_lone_eft_dma_radar_1_1_u_i_1_1_data_1_1_static_container_entry.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_data_1_1_static_container_entry" ]
        ] ],
        [ "ESP", "namespace_lone_eft_dma_radar_1_1_u_i_1_1_e_s_p.html", [
          [ "ESPManager", "class_lone_eft_dma_radar_1_1_u_i_1_1_e_s_p_1_1_e_s_p_manager.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_e_s_p_1_1_e_s_p_manager" ],
          [ "ESPWindow", "class_lone_eft_dma_radar_1_1_u_i_1_1_e_s_p_1_1_e_s_p_window.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_e_s_p_1_1_e_s_p_window" ],
          [ "ImGuiRenderContext", "struct_lone_eft_dma_radar_1_1_u_i_1_1_e_s_p_1_1_im_gui_render_context.html", "struct_lone_eft_dma_radar_1_1_u_i_1_1_e_s_p_1_1_im_gui_render_context" ]
        ] ],
        [ "Hotkeys", "namespace_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys.html", [
          [ "BooleanToBrushConverter", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_boolean_to_brush_converter.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_boolean_to_brush_converter" ],
          [ "ComboHotkeyValue", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_combo_hotkey_value.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_combo_hotkey_value" ],
          [ "HotkeyAction", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_hotkey_action.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_hotkey_action" ],
          [ "HotkeyActionController", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_hotkey_action_controller.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_hotkey_action_controller" ],
          [ "HotkeyBindingEntry", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_hotkey_binding_entry.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_hotkey_binding_entry" ],
          [ "HotkeyEventArgs", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_hotkey_event_args.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_hotkey_event_args" ],
          [ "HotkeyManagerTab", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_hotkey_manager_tab.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_hotkey_manager_tab" ],
          [ "HotkeyManagerViewModel", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_hotkey_manager_view_model.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_hotkey_manager_view_model" ],
          [ "HotkeyManagerWindow", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_hotkey_manager_window.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_hotkey_manager_window" ],
          [ "HotkeyModeListItem", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_hotkey_mode_list_item.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_hotkey_mode_list_item" ]
        ] ],
        [ "Loot", "namespace_lone_eft_dma_radar_1_1_u_i_1_1_loot.html", [
          [ "LootFilter", "class_lone_eft_dma_radar_1_1_u_i_1_1_loot_1_1_loot_filter.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_loot_1_1_loot_filter" ],
          [ "LootFilterEntry", "class_lone_eft_dma_radar_1_1_u_i_1_1_loot_1_1_loot_filter_entry.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_loot_1_1_loot_filter_entry" ],
          [ "UserLootFilter", "class_lone_eft_dma_radar_1_1_u_i_1_1_loot_1_1_user_loot_filter.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_loot_1_1_user_loot_filter" ]
        ] ],
        [ "Misc", "namespace_lone_eft_dma_radar_1_1_u_i_1_1_misc.html", [
          [ "Ballistics", "namespace_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_ballistics.html", [
            [ "BallisticSimulationOutput", "struct_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_ballistics_1_1_ballistic_simulation_output.html", "struct_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_ballistics_1_1_ballistic_simulation_output" ],
            [ "BallisticsInfo", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_ballistics_1_1_ballistics_info.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_ballistics_1_1_ballistics_info" ],
            [ "BallisticsSimulation", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_ballistics_1_1_ballistics_simulation.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_ballistics_1_1_ballistics_simulation" ],
            [ "G1", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_ballistics_1_1_g1.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_ballistics_1_1_g1" ],
            [ "G1DragModel", "struct_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_ballistics_1_1_g1_drag_model.html", "struct_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_ballistics_1_1_g1_drag_model" ]
          ] ],
          [ "DebugLogger", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_debug_logger.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_debug_logger" ],
          [ "DeviceAimbot", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_device_aimbot.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_device_aimbot" ],
          [ "DeviceNetController", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_device_net_controller.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_device_net_controller" ],
          [ "FirearmManager", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_firearm_manager.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_firearm_manager" ],
          [ "InputBoxViewModel", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_input_box_view_model.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_input_box_view_model" ],
          [ "InputBoxWindow", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_input_box_window.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_input_box_window" ],
          [ "KmBoxNetClient", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_km_box_net_client.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_km_box_net_client" ],
          [ "LoadingViewModel", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_loading_view_model.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_loading_view_model" ],
          [ "LoadingWindow", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_loading_window.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_loading_window" ],
          [ "MonitorInfo", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_monitor_info.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_monitor_info" ],
          [ "SimpleCommand", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_simple_command.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_simple_command" ],
          [ "StringToBrushConverter", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_string_to_brush_converter.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_string_to_brush_converter" ],
          [ "StringToColorConverter", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_string_to_color_converter.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_string_to_color_converter" ],
          [ "Vector3Extensions", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_vector3_extensions.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_vector3_extensions" ]
        ] ],
        [ "Radar", "namespace_lone_eft_dma_radar_1_1_u_i_1_1_radar.html", [
          [ "Maps", "namespace_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_maps.html", [
            [ "EftMapConfig", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_maps_1_1_eft_map_config.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_maps_1_1_eft_map_config" ],
            [ "EftMapManager", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_maps_1_1_eft_map_manager.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_maps_1_1_eft_map_manager" ],
            [ "EftMapParams", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_maps_1_1_eft_map_params.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_maps_1_1_eft_map_params" ],
            [ "EftSvgMap", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_maps_1_1_eft_svg_map.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_maps_1_1_eft_svg_map" ]
          ] ],
          [ "ViewModels", "namespace_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models.html", [
            [ "DebugTabViewModel", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_debug_tab_view_model.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_debug_tab_view_model" ],
            [ "DeviceAimbotViewModel", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_device_aimbot_view_model.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_device_aimbot_view_model" ],
            [ "EspSettingsViewModel", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_esp_settings_view_model.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_esp_settings_view_model" ],
            [ "LootFiltersViewModel", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_loot_filters_view_model.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_loot_filters_view_model" ],
            [ "MapSetupHelperViewModel", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_map_setup_helper_view_model.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_map_setup_helper_view_model" ],
            [ "MemoryInspectorEspField", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_memory_inspector_esp_field.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_memory_inspector_esp_field" ],
            [ "MemoryInspectorViewModel", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_memory_inspector_view_model.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_memory_inspector_view_model" ],
            [ "MemWritesViewModel", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_mem_writes_view_model.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_mem_writes_view_model" ],
            [ "OffsetFieldInfo", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_offset_field_info.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_offset_field_info" ],
            [ "RadarOverlayViewModel", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_radar_overlay_view_model.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_radar_overlay_view_model" ],
            [ "RadarViewModel", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_radar_view_model.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_radar_view_model" ],
            [ "SettingsViewModel", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_settings_view_model.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_settings_view_model" ],
            [ "StaticContainersViewModel", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_static_containers_view_model.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_static_containers_view_model" ],
            [ "WebRadarViewModel", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_web_radar_view_model.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_web_radar_view_model" ]
          ] ],
          [ "Views", "namespace_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views.html", [
            [ "DebugTab", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_debug_tab.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_debug_tab" ],
            [ "DeviceAimbotTab", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_device_aimbot_tab.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_device_aimbot_tab" ],
            [ "EspSettingsTab", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_esp_settings_tab.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_esp_settings_tab" ],
            [ "LootFiltersTab", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_loot_filters_tab.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_loot_filters_tab" ],
            [ "MapSetupHelper", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_map_setup_helper.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_map_setup_helper" ],
            [ "MemWritesTab", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_mem_writes_tab.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_mem_writes_tab" ],
            [ "RadarOverlay", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_radar_overlay.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_radar_overlay" ],
            [ "RadarTab", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_radar_tab.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_radar_tab" ],
            [ "SettingsTab", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_settings_tab.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_settings_tab" ],
            [ "StaticContainersTab", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_static_containers_tab.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_static_containers_tab" ],
            [ "WebRadarTab", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_web_radar_tab.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_web_radar_tab" ]
          ] ]
        ] ],
        [ "Skia", "namespace_lone_eft_dma_radar_1_1_u_i_1_1_skia.html", [
          [ "AbstractSKWidget", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_abstract_s_k_widget.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_abstract_s_k_widget" ],
          [ "AimviewWidget", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_aimview_widget.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_aimview_widget" ],
          [ "CustomFontManager", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_custom_font_manager.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_custom_font_manager" ],
          [ "CustomFonts", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_custom_fonts.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_custom_fonts" ],
          [ "LootInfoWidget", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_loot_info_widget.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_loot_info_widget" ],
          [ "PlayerInfoWidget", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_player_info_widget.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_player_info_widget" ],
          [ "SKFonts", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_s_k_fonts.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_s_k_fonts" ],
          [ "SkiaExtensions", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_skia_extensions.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_skia_extensions" ],
          [ "SKPaints", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_s_k_paints.html", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_s_k_paints" ]
        ] ]
      ] ],
      [ "Web", "namespace_lone_eft_dma_radar_1_1_web.html", [
        [ "TarkovDev", "namespace_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev.html", [
          [ "Data", "namespace_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data.html", [
            [ "FleaTax", "class_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data_1_1_flea_tax.html", "class_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data_1_1_flea_tax" ],
            [ "TarkovDevDataJob", "class_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data_1_1_tarkov_dev_data_job.html", "class_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data_1_1_tarkov_dev_data_job" ],
            [ "TarkovDevDataQuery", "class_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data_1_1_tarkov_dev_data_query.html", "class_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data_1_1_tarkov_dev_data_query" ],
            [ "TarkovDevGraphQLApi", "class_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data_1_1_tarkov_dev_graph_q_l_api.html", "class_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data_1_1_tarkov_dev_graph_q_l_api" ],
            [ "TarkovMarketItem", "class_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data_1_1_tarkov_market_item.html", "class_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data_1_1_tarkov_market_item" ]
          ] ]
        ] ],
        [ "WebRadar", "namespace_lone_eft_dma_radar_1_1_web_1_1_web_radar.html", [
          [ "Data", "namespace_lone_eft_dma_radar_1_1_web_1_1_web_radar_1_1_data.html", [
            [ "WebRadarPlayer", "struct_lone_eft_dma_radar_1_1_web_1_1_web_radar_1_1_data_1_1_web_radar_player.html", "struct_lone_eft_dma_radar_1_1_web_1_1_web_radar_1_1_data_1_1_web_radar_player" ],
            [ "WebRadarUpdate", "class_lone_eft_dma_radar_1_1_web_1_1_web_radar_1_1_data_1_1_web_radar_update.html", "class_lone_eft_dma_radar_1_1_web_1_1_web_radar_1_1_data_1_1_web_radar_update" ]
          ] ],
          [ "MessagePack", "namespace_lone_eft_dma_radar_1_1_web_1_1_web_radar_1_1_message_pack.html", [
            [ "ResolverGenerator", "class_lone_eft_dma_radar_1_1_web_1_1_web_radar_1_1_message_pack_1_1_resolver_generator.html", "class_lone_eft_dma_radar_1_1_web_1_1_web_radar_1_1_message_pack_1_1_resolver_generator" ],
            [ "Vector2Formatter", "class_lone_eft_dma_radar_1_1_web_1_1_web_radar_1_1_message_pack_1_1_vector2_formatter.html", "class_lone_eft_dma_radar_1_1_web_1_1_web_radar_1_1_message_pack_1_1_vector2_formatter" ],
            [ "Vector3Formatter", "class_lone_eft_dma_radar_1_1_web_1_1_web_radar_1_1_message_pack_1_1_vector3_formatter.html", "class_lone_eft_dma_radar_1_1_web_1_1_web_radar_1_1_message_pack_1_1_vector3_formatter" ]
          ] ],
          [ "WebRadarServer", "class_lone_eft_dma_radar_1_1_web_1_1_web_radar_1_1_web_radar_server.html", "class_lone_eft_dma_radar_1_1_web_1_1_web_radar_1_1_web_radar_server" ]
        ] ]
      ] ],
      [ "AimviewWidgetConfig", "class_lone_eft_dma_radar_1_1_aimview_widget_config.html", "class_lone_eft_dma_radar_1_1_aimview_widget_config" ],
      [ "App", "class_lone_eft_dma_radar_1_1_app.html", "class_lone_eft_dma_radar_1_1_app" ],
      [ "ContainersConfig", "class_lone_eft_dma_radar_1_1_containers_config.html", "class_lone_eft_dma_radar_1_1_containers_config" ],
      [ "EftDmaConfig", "class_lone_eft_dma_radar_1_1_eft_dma_config.html", "class_lone_eft_dma_radar_1_1_eft_dma_config" ],
      [ "ExtendedReachConfig", "class_lone_eft_dma_radar_1_1_extended_reach_config.html", "class_lone_eft_dma_radar_1_1_extended_reach_config" ],
      [ "MainWindow", "class_lone_eft_dma_radar_1_1_main_window.html", "class_lone_eft_dma_radar_1_1_main_window" ],
      [ "MainWindowViewModel", "class_lone_eft_dma_radar_1_1_main_window_view_model.html", "class_lone_eft_dma_radar_1_1_main_window_view_model" ],
      [ "MiniRadarConfig", "class_lone_eft_dma_radar_1_1_mini_radar_config.html", "class_lone_eft_dma_radar_1_1_mini_radar_config" ],
      [ "TarkovDevConfig", "class_lone_eft_dma_radar_1_1_tarkov_dev_config.html", "class_lone_eft_dma_radar_1_1_tarkov_dev_config" ],
      [ "UIConfig", "class_lone_eft_dma_radar_1_1_u_i_config.html", "class_lone_eft_dma_radar_1_1_u_i_config" ]
    ] ],
    [ "SDK", "namespace_s_d_k.html", [
      [ "Offsets", "struct_s_d_k_1_1_offsets.html", "struct_s_d_k_1_1_offsets" ]
    ] ],
    [ "AIRole", "struct_a_i_role.html", "struct_a_i_role" ],
    [ "MagazineManager", "class_magazine_manager.html", "class_magazine_manager" ]
];