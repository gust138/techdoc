var dir_e01e35249561718bfd804c9071543e5b =
[
    [ "FleaTax.cs", "_flea_tax_8cs.html", "_flea_tax_8cs" ],
    [ "TarkovDevDataJob.cs", "_tarkov_dev_data_job_8cs.html", "_tarkov_dev_data_job_8cs" ],
    [ "TarkovDevDataQuery.cs", "_tarkov_dev_data_query_8cs.html", "_tarkov_dev_data_query_8cs" ],
    [ "TarkovDevGraphQLApi.cs", "_tarkov_dev_graph_q_l_api_8cs.html", "_tarkov_dev_graph_q_l_api_8cs" ],
    [ "TarkovMarketItem.cs", "_tarkov_market_item_8cs.html", "_tarkov_market_item_8cs" ]
];