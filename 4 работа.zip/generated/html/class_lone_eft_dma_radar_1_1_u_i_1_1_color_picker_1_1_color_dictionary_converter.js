var class_lone_eft_dma_radar_1_1_u_i_1_1_color_picker_1_1_color_dictionary_converter =
[
    [ "Read", "class_lone_eft_dma_radar_1_1_u_i_1_1_color_picker_1_1_color_dictionary_converter.html#a2a56f4433d9195541676086cac0299bf", null ],
    [ "Write", "class_lone_eft_dma_radar_1_1_u_i_1_1_color_picker_1_1_color_dictionary_converter.html#aae14a73c61ee975f5ff3ea429dedad3b", null ]
];