var namespace_lone_eft_dma_radar_1_1_common =
[
    [ "DMA", "namespace_lone_eft_dma_radar_1_1_common_1_1_d_m_a.html", "namespace_lone_eft_dma_radar_1_1_common_1_1_d_m_a" ],
    [ "Misc", "namespace_lone_eft_dma_radar_1_1_common_1_1_misc.html", "namespace_lone_eft_dma_radar_1_1_common_1_1_misc" ]
];