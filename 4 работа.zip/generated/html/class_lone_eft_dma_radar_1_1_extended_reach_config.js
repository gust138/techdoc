var class_lone_eft_dma_radar_1_1_extended_reach_config =
[
    [ "Distance", "class_lone_eft_dma_radar_1_1_extended_reach_config.html#ada94d4e72542bc822f6f6572b61e7565", null ],
    [ "Enabled", "class_lone_eft_dma_radar_1_1_extended_reach_config.html#acff0ff411deda7706072ef7f3372c6db", null ],
    [ "set", "class_lone_eft_dma_radar_1_1_extended_reach_config.html#aba07bc87a1a39bad1a09896b3b52ad66", null ]
];