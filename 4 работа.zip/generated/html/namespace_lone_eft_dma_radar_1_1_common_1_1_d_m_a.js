var namespace_lone_eft_dma_radar_1_1_common_1_1_d_m_a =
[
    [ "MemPointer", "struct_lone_eft_dma_radar_1_1_common_1_1_d_m_a_1_1_mem_pointer.html", "struct_lone_eft_dma_radar_1_1_common_1_1_d_m_a_1_1_mem_pointer" ],
    [ "FpgaAlgo", "namespace_lone_eft_dma_radar_1_1_common_1_1_d_m_a.html#aabfafaea6adee43e93b7246dd16ac844", [
      [ "Auto", "namespace_lone_eft_dma_radar_1_1_common_1_1_d_m_a.html#aabfafaea6adee43e93b7246dd16ac844ab0e7cd22cce9766c23c617b80ae781a9", null ],
      [ "AsyncNormal", "namespace_lone_eft_dma_radar_1_1_common_1_1_d_m_a.html#aabfafaea6adee43e93b7246dd16ac844a0dbd1ad4ccc644ee26826cb99e42f903", null ],
      [ "AsyncTiny", "namespace_lone_eft_dma_radar_1_1_common_1_1_d_m_a.html#aabfafaea6adee43e93b7246dd16ac844aa3272c50c3592b23e3ae04343f5c0cc3", null ],
      [ "OldNormal", "namespace_lone_eft_dma_radar_1_1_common_1_1_d_m_a.html#aabfafaea6adee43e93b7246dd16ac844a25a6d933f9f83c2693b8ee6a81aa97b7", null ],
      [ "OldTiny", "namespace_lone_eft_dma_radar_1_1_common_1_1_d_m_a.html#aabfafaea6adee43e93b7246dd16ac844abb5357baaeb0f4bab1cb5fa4d8ebdd67", null ]
    ] ]
];