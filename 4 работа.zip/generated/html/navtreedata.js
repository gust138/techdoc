/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Moulman EFT DMA Radar", "index.html", [
    [ "Документация Moulman EFT DMA Radar", "index.html", "index" ],
    [ "Пакеты", "namespaces.html", [
      [ "Список пакетов", "namespaces.html", "namespaces_dup" ],
      [ "Члены с областью видимости пакета", "namespacemembers.html", [
        [ "Указатель", "namespacemembers.html", "namespacemembers_dup" ],
        [ "Функции", "namespacemembers_func.html", null ],
        [ "Переменные", "namespacemembers_vars.html", "namespacemembers_vars" ],
        [ "Перечисления", "namespacemembers_enum.html", null ],
        [ "Элементы перечислений", "namespacemembers_eval.html", null ]
      ] ]
    ] ],
    [ "Классы", "annotated.html", [
      [ "Классы", "annotated.html", "annotated_dup" ],
      [ "Алфавитный указатель классов", "classes.html", null ],
      [ "Иерархия классов", "hierarchy.html", "hierarchy" ],
      [ "Члены классов", "functions.html", [
        [ "Указатель", "functions.html", "functions_dup" ],
        [ "Функции", "functions_func.html", "functions_func" ],
        [ "Переменные", "functions_vars.html", "functions_vars" ],
        [ "Перечисления", "functions_enum.html", null ],
        [ "Элементы перечислений", "functions_eval.html", null ]
      ] ]
    ] ],
    [ "Файлы", "files.html", [
      [ "Файлы", "files.html", "files_dup" ],
      [ "Список членов всех файлов", "globals.html", [
        [ "Указатель", "globals.html", "globals_dup" ],
        [ "Функции", "globals_func.html", null ],
        [ "Переменные", "globals_vars.html", "globals_vars" ],
        [ "Определения типов", "globals_type.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_abstract_player_8cs.html",
"_eft_dma_config_8cs.html#a615c761f28bae31e69e46011bf09a459",
"_mem_writes_tab_8xaml_8cs_source.html",
"class_lone_eft_dma_radar_1_1_aimview_widget_config.html#ad103262cef71c40972ff5a14436fe677",
"class_lone_eft_dma_radar_1_1_d_m_a_1_1_memory.html#a424aa25d36744202e4ac124fe212253c",
"class_lone_eft_dma_radar_1_1_mini_radar_config.html#ae953856c561028e2c44633110e8c0a89",
"class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_infinite_stamina.html#a3b2e10d97cfdb3efc71eb1873b312315",
"class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_camera_1_1_camera_manager.html#a452ef122c581018993681aafa862bb72",
"class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_game_world_extensions.html#a24683fdd196134ccf4bb75c6e18685aa",
"class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_loot_1_1_static_loot_container.html#a82859fb5155dc0be7a195e09dbdc195a",
"class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_client_player.html#adf13e08187d4d3edbca0afc6f9c18db9",
"class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_registered_players.html#a0a9a4ce714f05f2e8137663d740f9204",
"class_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_unity_transform.html#a1dbdab6ddab7c067e46e21ced6d3d912",
"class_lone_eft_dma_radar_1_1_u_i_1_1_e_s_p_1_1_e_s_p_window.html#a6be2ad0cd1719469a111983d85bed30b",
"class_lone_eft_dma_radar_1_1_u_i_1_1_hotkeys_1_1_hotkey_manager_view_model.html",
"class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_device_aimbot.html#a55b83947a4e0b3119868470f18205793",
"class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_loading_view_model.html#a42201fb2800962d066845c062692ae3d",
"class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_device_aimbot_view_model.html#a270e625a2c0564cf0294ed419a7ae511",
"class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_loot_filters_view_model.html#aee3e3bb49e33a36b1dc1f2c6e12b7d9f",
"class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_view_models_1_1_radar_overlay_view_model.html#a54277727e379fed540ed850b6c357e62",
"class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_abstract_s_k_widget.html#a1bd94f179b2994cdf8400001bed96074",
"class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_s_k_paints.html#a4a68151c8f1169608f2459effd9b57e2",
"class_lone_eft_dma_radar_1_1_u_i_config.html#a9650ebf7d794d47d57e2d863173f9360",
"class_lone_eft_dma_radar_1_1_web_1_1_web_radar_1_1_message_pack_1_1_vector2_formatter.html#ab8e1edf06ac54920ae7995373bcf9719",
"namespace_lone_eft_dma_radar.html#a9725dd632e44e6c0f32dfd568775ef86",
"namespace_lone_eft_dma_radar_1_1_u_i_1_1_e_s_p.html#abd46ad1b35102bcacebef1e3f6c1c85d",
"namespacemembers_vars_b.html",
"struct_lone_eft_dma_radar_1_1_tarkov_1_1_unity_1_1_structures_1_1_dynamic_array.html#a8f15f03e336eed1adac1415c23ecb9da",
"struct_s_d_k_1_1_offsets.html",
"struct_s_d_k_1_1_offsets.html#aeb29c2bfba880b8979961808cb6e5bba",
"struct_s_d_k_1_1_offsets_1_1_weapon_template.html"
];

const SYNCONMSG = 'нажмите на выключить для синхронизации панелей';
const SYNCOFFMSG = 'нажмите на включить для синхронизации панелей';
const LISTOFALLMEMBERS = 'Полный список членов класса';