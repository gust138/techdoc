var index =
[
    [ "Генерация", "index.html#autotoc_md1", null ],
    [ "Структура решения", "index.html#autotoc_md2", null ],
    [ "Жизненный цикл данных", "index.html#autotoc_md3", null ],
    [ "Дополнение комментариев", "index.html#autotoc_md4", null ]
];