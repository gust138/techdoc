var class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_mem_writes_tab =
[
    [ "MemWritesTab", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_mem_writes_tab.html#a2cb84b8dae806a30ccdabb69814d0e9c", null ],
    [ "ViewModel", "class_lone_eft_dma_radar_1_1_u_i_1_1_radar_1_1_views_1_1_mem_writes_tab.html#a1302fc2459cf2b5aa9a0ce49d0a6d29c", null ]
];