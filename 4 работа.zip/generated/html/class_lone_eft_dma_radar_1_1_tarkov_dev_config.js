var class_lone_eft_dma_radar_1_1_tarkov_dev_config =
[
    [ "Enabled", "class_lone_eft_dma_radar_1_1_tarkov_dev_config.html#a98b7a59bae36485b1adfcdf1edda9b43", null ],
    [ "Priority", "class_lone_eft_dma_radar_1_1_tarkov_dev_config.html#a67319b03afdf7afb9a16f42a9bfcb4bf", null ],
    [ "set", "class_lone_eft_dma_radar_1_1_tarkov_dev_config.html#ae242d7e9254f38c566c77d9e6740a06a", null ]
];