var class_lone_eft_dma_radar_1_1_misc_1_1_native =
[
    [ "EXECUTION_STATE", "class_lone_eft_dma_radar_1_1_misc_1_1_native.html#a4ebf510091dd755e1339bc24bb220930", [
      [ "ES_AWAYMODE_REQUIRED", "class_lone_eft_dma_radar_1_1_misc_1_1_native.html#a4ebf510091dd755e1339bc24bb220930aaad89e0abb55635d8156947fdc8e1dd0", null ],
      [ "ES_CONTINUOUS", "class_lone_eft_dma_radar_1_1_misc_1_1_native.html#a4ebf510091dd755e1339bc24bb220930a09d9c8620dd68e593c7073cba702d248", null ],
      [ "ES_DISPLAY_REQUIRED", "class_lone_eft_dma_radar_1_1_misc_1_1_native.html#a4ebf510091dd755e1339bc24bb220930a58e98c9682a7835dd0d2c273e80aeec9", null ],
      [ "ES_SYSTEM_REQUIRED", "class_lone_eft_dma_radar_1_1_misc_1_1_native.html#a4ebf510091dd755e1339bc24bb220930ac962010a836060bc604484414df31715", null ]
    ] ],
    [ "PowerSetActiveScheme", "class_lone_eft_dma_radar_1_1_misc_1_1_native.html#a4482d704150e571222f5b1152158a68c", null ],
    [ "SetThreadExecutionState", "class_lone_eft_dma_radar_1_1_misc_1_1_native.html#a18939caffff9cecd895276678e54ab5c", null ],
    [ "QUOTA_LIMITS_HARDWS_MAX_DISABLE", "class_lone_eft_dma_radar_1_1_misc_1_1_native.html#a88b957a77d39e48de8db6a1e89e450db", null ],
    [ "QUOTA_LIMITS_HARDWS_MAX_ENABLE", "class_lone_eft_dma_radar_1_1_misc_1_1_native.html#ae2afe3a353c0591fcb15c851b6e77bc7", null ],
    [ "QUOTA_LIMITS_HARDWS_MIN_DISABLE", "class_lone_eft_dma_radar_1_1_misc_1_1_native.html#ab673c3986a15f9af245f8b04cf738dde", null ],
    [ "QUOTA_LIMITS_HARDWS_MIN_ENABLE", "class_lone_eft_dma_radar_1_1_misc_1_1_native.html#a7b47af3201c75a371fdf116266f82f86", null ]
];