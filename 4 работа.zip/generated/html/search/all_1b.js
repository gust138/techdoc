var searchData=
[
  ['генерация_0',['Генерация',['../index.html#autotoc_md1',1,'']]]
];
