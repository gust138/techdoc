var searchData=
[
  ['решения_0',['Структура решения',['../index.html#autotoc_md2',1,'']]]
];
