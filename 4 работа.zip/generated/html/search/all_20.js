var searchData=
[
  ['структура_20решения_0',['Структура решения',['../index.html#autotoc_md2',1,'']]]
];
