var searchData=
[
  ['dxcolor_0',['DxColor',['../_e_s_p_window_8xaml_8cs.html#a0bba14c9faef0f10c5715e7ac7f5fde9',1,'ESPWindow.xaml.cs']]]
];
