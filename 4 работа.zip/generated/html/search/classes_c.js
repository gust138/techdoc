var searchData=
[
  ['native_0',['Native',['../class_lone_eft_dma_radar_1_1_misc_1_1_native.html',1,'LoneEftDmaRadar::Misc']]],
  ['norecoil_1',['NoRecoil',['../class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html',1,'LoneEftDmaRadar::Tarkov::Features::MemWrites']]]
];
