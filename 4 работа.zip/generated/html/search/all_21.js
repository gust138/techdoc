var searchData=
[
  ['цикл_20данных_0',['Жизненный цикл данных',['../index.html#autotoc_md3',1,'']]]
];
