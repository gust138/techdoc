var class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_btr_player =
[
    [ "_btrView", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_btr_player.html#a23d962331e5a51bc0bfba70dbb49c9a9", null ],
    [ "_posAddr", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_btr_player.html#a878d1a81c59d5b04463a13eee2e6374d", null ],
    [ "_position", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_btr_player.html#a1774933b7cfd02d5dd562a8d2e6694d6", null ],
    [ "Name", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_btr_player.html#aaf86992f44d379e468257f7791e90961", null ],
    [ "Position", "class_lone_eft_dma_radar_1_1_tarkov_1_1_game_world_1_1_player_1_1_btr_player.html#a796a2cd4140863b17fdc92a18c1e431d", null ]
];