var class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_custom_font_manager =
[
    [ "CreateRadarWidgetFont", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_custom_font_manager.html#a07f9c9f77ea4af690eb9a7ebe0bf5614", null ],
    [ "GetCurrentRadarWidgetFont", "class_lone_eft_dma_radar_1_1_u_i_1_1_skia_1_1_custom_font_manager.html#a424ff85da032887fdf80e9569c84bca2", null ]
];