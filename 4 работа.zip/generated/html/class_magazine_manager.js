var class_magazine_manager =
[
    [ "_ammo", "class_magazine_manager.html#abc83ca1f10f74850774f332c748d876e", null ],
    [ "_fireType", "class_magazine_manager.html#a200c328e1f14afa8743be7ac5f7807f1", null ],
    [ "_localPlayer", "class_magazine_manager.html#ac8c357adb73ee4fbf24ca8d110368b1b", null ],
    [ "Count", "class_magazine_manager.html#a8fb7e2bf0b2a10b0507f1c36122ab930", null ],
    [ "IsValid", "class_magazine_manager.html#a08ca2097e8fcaa3da66196af38a3b6f4", null ],
    [ "MaxCount", "class_magazine_manager.html#a583739ebd12903a9464b5f4bc72f2ae6", null ],
    [ "set", "class_magazine_manager.html#a514bb6e2ad3ca98253494fb0f56486e4", null ]
];