var class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_input_box_view_model_1_1_close_requested_event_args =
[
    [ "CloseRequestedEventArgs", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_input_box_view_model_1_1_close_requested_event_args.html#af8a7fd91bb1627fe87705f9c48f8079f", null ],
    [ "DialogResult", "class_lone_eft_dma_radar_1_1_u_i_1_1_misc_1_1_input_box_view_model_1_1_close_requested_event_args.html#aee8e24fd2166dc1c68e690cacfabea9c", null ]
];