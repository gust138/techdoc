var class_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data_1_1_flea_tax =
[
    [ "Calculate", "class_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data_1_1_flea_tax.html#a69d65e596ec3fd8cea7c5635a7627a64", null ],
    [ "CommunityItemTax", "class_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data_1_1_flea_tax.html#a7cd53db1b427d309b52a3acce858706f", null ],
    [ "CommunityRequirementTax", "class_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data_1_1_flea_tax.html#a08ef759d2b50afcb88edd01b576289da", null ],
    [ "RagFairCommissionModifier", "class_lone_eft_dma_radar_1_1_web_1_1_tarkov_dev_1_1_data_1_1_flea_tax.html#a411379d0729109e0bf6f6b68678479d6", null ]
];