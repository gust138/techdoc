var class_lone_eft_dma_radar_1_1_misc_1_1_workers_1_1_worker_thread_args =
[
    [ "WorkerThreadArgs", "class_lone_eft_dma_radar_1_1_misc_1_1_workers_1_1_worker_thread_args.html#aedbd092c81802c73dd03cc74c98b0cfc", null ],
    [ "CancellationToken", "class_lone_eft_dma_radar_1_1_misc_1_1_workers_1_1_worker_thread_args.html#af4fa687fd745659fcbfb16e8bd60488e", null ]
];