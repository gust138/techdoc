var class_lone_eft_dma_radar_1_1_misc_1_1_j_s_o_n_1_1_s_k_rect_json_converter =
[
    [ "Read", "class_lone_eft_dma_radar_1_1_misc_1_1_j_s_o_n_1_1_s_k_rect_json_converter.html#a43d1ce86938f8d20256c711e9825ac2b", null ],
    [ "Write", "class_lone_eft_dma_radar_1_1_misc_1_1_j_s_o_n_1_1_s_k_rect_json_converter.html#accc34ddb85f0fe7278b8d50e6018a005", null ]
];