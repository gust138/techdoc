var struct_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_debug_sw_averages =
[
    [ "DebugSwAverages", "struct_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_debug_sw_averages.html#adf1be16a05f0d24a8defbeaaaad8974d", null ],
    [ "Add", "struct_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_debug_sw_averages.html#a66561520bba2d3864d92a7d7ce20211e", null ],
    [ "TryGetAverage", "struct_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_debug_sw_averages.html#aa619aa23ff7390fc33eeb6c9fa24ceaa", null ],
    [ "_timer", "struct_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_debug_sw_averages.html#ab5e93eb279e2e22494adb27aeb0ac12a", null ],
    [ "_values", "struct_lone_eft_dma_radar_1_1_common_1_1_misc_1_1_debug_sw_averages.html#ae76dca29ab9ff6f934cf321376ba731c", null ]
];