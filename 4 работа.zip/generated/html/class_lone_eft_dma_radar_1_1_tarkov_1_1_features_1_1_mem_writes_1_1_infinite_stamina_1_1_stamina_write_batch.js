var class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_infinite_stamina_1_1_stamina_write_batch =
[
    [ "Entry", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_infinite_stamina_1_1_stamina_write_batch_1_1_entry.html", "struct_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_infinite_stamina_1_1_stamina_write_batch_1_1_entry" ],
    [ "StaminaWriteBatch", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_infinite_stamina_1_1_stamina_write_batch.html#aec924866f2fcbe651a0421e47c952ce0", null ],
    [ "Add", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_infinite_stamina_1_1_stamina_write_batch.html#a3669ec0dfacbf9c85c21eee346b7d422", null ],
    [ "Execute", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_infinite_stamina_1_1_stamina_write_batch.html#adb72bfe690dafb4d06d349e105f3b816", null ],
    [ "_count", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_infinite_stamina_1_1_stamina_write_batch.html#aaff4787b7c45fccb2a53d4bf825a7101", null ],
    [ "_entries", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_infinite_stamina_1_1_stamina_write_batch.html#aa029858efa32a58283d0db26e23b5e4e", null ],
    [ "HasWrites", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_infinite_stamina_1_1_stamina_write_batch.html#aa80781b5ddf0f9caf332463c0b2e0894", null ]
];