var class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_mem_writes_manager =
[
    [ "MemWritesManager", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_mem_writes_manager.html#ad7fcab722c6f2eccee8e0d7f527388e3", null ],
    [ "Apply", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_mem_writes_manager.html#a9999d0cdd89c23d6f2721a9f2a5944b3", null ],
    [ "OnRaidStart", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_mem_writes_manager.html#af4190783a7d70a74664dec6ae4f331f5", null ],
    [ "TryApplyAntiAfk", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_mem_writes_manager.html#ab08b33d7104d0d0d4b9a9cb8dc2258bd", null ],
    [ "_lastAntiAfkRun", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_mem_writes_manager.html#ac6ad72b453caf093ad6710f7988abba9", null ],
    [ "_raidFeatures", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_mem_writes_manager.html#ae97893866978191e162e1de4327fb42a", null ],
    [ "AntiAfkDelay", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_mem_writes_manager.html#a22d7e8399145a76f809fd8e5ff33fa15", null ]
];