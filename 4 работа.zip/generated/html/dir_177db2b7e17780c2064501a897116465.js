var dir_177db2b7e17780c2064501a897116465 =
[
    [ "ColorDictionaryConverter.cs", "_color_dictionary_converter_8cs.html", "_color_dictionary_converter_8cs" ],
    [ "ColorPickerOption.cs", "_color_picker_option_8cs.html", "_color_picker_option_8cs" ],
    [ "ColorPickerViewModel.cs", "_color_picker_view_model_8cs.html", "_color_picker_view_model_8cs" ],
    [ "ColorPickerWindow.xaml.cs", "_color_picker_window_8xaml_8cs.html", "_color_picker_window_8xaml_8cs" ]
];