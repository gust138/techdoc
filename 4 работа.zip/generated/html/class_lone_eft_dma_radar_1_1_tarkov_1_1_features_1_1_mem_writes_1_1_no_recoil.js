var class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil =
[
    [ "EProceduralAnimationMask", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#ab10e13ad67c1f0a3df840bb38217ea02", [
      [ "Breathing", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#ab10e13ad67c1f0a3df840bb38217ea02a8a4978906679c7b491338d7f71a5fbb3", null ],
      [ "Walking", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#ab10e13ad67c1f0a3df840bb38217ea02a25b933c009c85b442ba9d62cbfa60e63", null ],
      [ "MotionReaction", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#ab10e13ad67c1f0a3df840bb38217ea02a9eeeb3baa17ce69d351fb113a2e4f83a", null ],
      [ "ForceReaction", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#ab10e13ad67c1f0a3df840bb38217ea02a7fcb7dc80b7c7c54d6894a424f67bdf3", null ],
      [ "Shooting", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#ab10e13ad67c1f0a3df840bb38217ea02a14fb8471bfccb11445073b76d516cd9c", null ],
      [ "DrawDown", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#ab10e13ad67c1f0a3df840bb38217ea02a1b9406c9a5d0fcd897494ccf7237dd9a", null ],
      [ "Aiming", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#ab10e13ad67c1f0a3df840bb38217ea02af55766d7b0f0b49f7ddf2eb31ef5efc5", null ],
      [ "HandShake", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#ab10e13ad67c1f0a3df840bb38217ea02acbe7d5634df7b218e42ead598d077a93", null ]
    ] ],
    [ "ApplyNoRecoil", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#a79f999ef05ebd7edc48d091b485277d8", null ],
    [ "ClearCache", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#a4da43c1cdd358c05774383f52e64dca2", null ],
    [ "GetEffectorPointers", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#a5c3cced9b1fea19e224d2f4956e733fd", null ],
    [ "OnRaidStart", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#ae70cccc03bdfdfb972df3a2adcfd8cbd", null ],
    [ "ResetNoRecoil", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#a87f94182b2f5fd8c3e4e3955d405a7aa", null ],
    [ "TryApply", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#a83fa9ce2cb860331fdceea320f71d438", null ],
    [ "ValidatePointers", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#a8d5d55bf519c360695ab9849e13ca9d0", null ],
    [ "_cachedBreathEffector", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#ad3fecc47460e838221a0761aa67c15a4", null ],
    [ "_cachedNewShotRecoil", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#a6caa624c2e3d83b7454f6141ebcb4b51", null ],
    [ "_cachedShotEffector", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#a99e276f53f56ba5ffc56891a83f39d62", null ],
    [ "_lastEnabledState", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#a18f6792e1a10575744eb6a6a145d57dd", null ],
    [ "_lastPwaPtr", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#a1b5c39784a164524cf1d93e5d0c7d441", null ],
    [ "_lastRecoilAmount", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#ad0b4be24f15952d3be25a0bc684b732f", null ],
    [ "_lastSwayAmount", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#aec5100318b086f7e893bd6fc8ed9d7ae", null ],
    [ "breathEffector", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#aa1595f8967a7a68090557c8b91c383d1", null ],
    [ "Delay", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#a713911993ee86ae939d2a3c13c3d8794", null ],
    [ "Enabled", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#aef77f0d362b9a2f9ac30f7dde1701d92", null ],
    [ "ORIGINAL_PWA_MASK", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#a15951a60b70f786ba449e585a014eadc", null ],
    [ "set", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#aa762e1d0aaf1b6f957bf9ddd659727c5", null ],
    [ "shotEffector", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_no_recoil.html#ae62e109b45ca4d05f3dbb63b430120d8", null ]
];