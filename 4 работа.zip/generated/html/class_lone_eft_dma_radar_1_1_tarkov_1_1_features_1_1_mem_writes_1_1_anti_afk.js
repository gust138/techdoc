var class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_anti_afk =
[
    [ "Apply", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_anti_afk.html#a2e3874692e91d7fef2cee5e6b85bfcd3", null ],
    [ "OnRaidStart", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_anti_afk.html#a62feddba912b2dac86bdc118e24c1b6f", null ],
    [ "TryApply", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_anti_afk.html#a541ed8c3f25b8e0cd551e2e277940bf9", null ],
    [ "_applied", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_anti_afk.html#a0ce52af738c1609e457aa66e9a06d3e2", null ],
    [ "_lastEnabledState", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_anti_afk.html#a5c14574f19c2d6ef67dcc6686f57ff83", null ],
    [ "AFK_DELAY", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_anti_afk.html#afb9370e3457aa472ba5eb5198ae1d0cd", null ],
    [ "Delay", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_anti_afk.html#af533c8dd947c39243d26e34d8a9ff17f", null ],
    [ "Enabled", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_anti_afk.html#ae3942f200adb3c30f93b24cd9f9576cc", null ],
    [ "set", "class_lone_eft_dma_radar_1_1_tarkov_1_1_features_1_1_mem_writes_1_1_anti_afk.html#a3bee0d6fb55d4f6701c9db1faf248574", null ]
];